import React from "react";
import { ZegoGridLayoutProps } from "../../../../model";
export declare class ZegoGridLayout extends React.Component<ZegoGridLayoutProps> {
    render(): React.ReactNode;
}
