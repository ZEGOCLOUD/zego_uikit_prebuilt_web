/// <reference types="react" />
export declare function OthersVideo(props: {
    users: string[];
    others: number;
}): JSX.Element;
