import React from "react";
export declare class ZegoReconnect extends React.Component<{
    content: string;
}> {
    render(): React.ReactNode;
}
