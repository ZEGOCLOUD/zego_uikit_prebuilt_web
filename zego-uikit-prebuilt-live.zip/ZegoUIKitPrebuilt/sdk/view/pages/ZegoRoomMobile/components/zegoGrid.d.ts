import React from "react";
import { ZegoGridLayoutProps } from "../../../../model/index";
export declare class ZegoGrid extends React.Component<ZegoGridLayoutProps> {
    render(): React.ReactNode;
}
